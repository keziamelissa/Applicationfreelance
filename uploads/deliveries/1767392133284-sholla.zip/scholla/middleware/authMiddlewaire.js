const jwt = require('jsonwebtoken');

// Middleware pour vérifier si l'utilisateur est authentifié
const authMiddleware = (req, res, next) => {
    // Récupère le token d'autorisation depuis l'en-tête "Authorization"
    const token = req.header('Authorization');
    
    if (!token) {
        return res.status(401).json({ message: "Autorisation requise." });
    }

    try {
        // Vérifie et décode le token (utilise ton secret JWT)
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded; // Attache l'utilisateur décodé à la requête
        next(); // Continue si le token est valide
    } catch (error) {
        res.status(401).json({ message: "Token non valide." });
    }
};

module.exports = authMiddleware;

