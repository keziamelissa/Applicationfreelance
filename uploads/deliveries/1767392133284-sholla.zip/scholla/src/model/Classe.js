const mongoose = require('mongoose');

// Schéma pour Classe
const classeSchema = new mongoose.Schema({
    nom: { type: String, required: true },
    scolarite: { type: Number, required: true },
    titulaireClasse: { type: mongoose.Schema.Types.ObjectId, ref: 'Eleve' }  // Suppose que le titulaire de la classe est un élève (peut-être un cas particulier)
  });
  
  const Classe = mongoose.model('Classe', classeSchema);
  module.exports = Classe;