const mongoose = require('mongoose');

// Schéma pour `Appartenir
const appartenirSchema = new mongoose.Schema({
    anneeScolaire: { type: String, required: true },
    montantPayer: { type: Number, required: true },
    moyTr1: { type: Number },
    moyTr2: { type: Number },
    moyTr3: { type: Number },
    moyAnn: { type: Number },
    droitsInscr: { type: Boolean, default: true },
    rangTr1: { type: Number },
    rangTr2: { type: Number },
    rangTr3: { type: Number },
    rangAnn: { type: Number }
  });
  
  const Appartenir = mongoose.model('Appartenir', appartenirSchema);
  module.exports = Appartenir;