const mongoose = require('mongoose');

// Schéma pour `NoteClasse`
const NoteClasseSchema = new mongoose.Schema({
  anneeAcademique: { type: String, required: true },
  trimestre: { type: String, required: true },
  note1: { type: Number, required: true },
  note2: { type: Number, required: true },
  note3: { type: Number, required: true },
});

const NoteClasse = mongoose.model('NoteClasse', NoteClasseSchema);

module.exports = NoteClasse;