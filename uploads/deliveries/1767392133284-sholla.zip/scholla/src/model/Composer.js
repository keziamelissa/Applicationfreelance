const mongoose = require('mongoose');

// Schéma pour `Composer`
const composerSchema = new mongoose.Schema({
    anneeAcademique: { type: String, required: true },
    noteClasse: { type: mongoose.Schema.Types.ObjectId, ref: 'NoteClasse', required: true },
    compoClasse: { type: Number, required: true },
    moyTrim: { type: Number, required: true },
    coefTrim: { type: Number, required: true },
    trimestre: { type: String, required: true },
    rangMat: { type: Number },
    abdons: { type: Boolean, default: false }
  });
  

  // Middleware pour calculer les valeurs avant de sauvegarder
composerSchema.pre('save', async function(next) {
  const noteClasseDoc = await NoteClasse.findById(this.noteClasseId);
  if (noteClasseDoc) {
    this.noteClasse = (noteClasseDoc.note1 + noteClasseDoc.note2) / 2;
    this.compoClasse = noteClasseDoc.note3;
    this.moyTrim = (this.noteClasse + this.compoClasse) / 2;
  }
  next();
});

  const Composer = mongoose.model('Composer', composerSchema);
  module.exports = Composer;