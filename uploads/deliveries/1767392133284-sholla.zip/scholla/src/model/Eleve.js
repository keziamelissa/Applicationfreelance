const mongoose = require('mongoose');

// Schéma pour `Elève`
const eleveSchema = new mongoose.Schema({
    nom: { type: String, required: true },
    matricule: { type: String, required: true, unique: true },
    prenom: { type: String, required: true },
    dateNaiss: { type: Date, required: true },
    lieuNaiss: { type: String, required: true },
    sexe: { type: String, required: true },
    nationalite: { type: String, required: true },
    paysOrigine: { type: String },
    nomPere: { type: String },
    adressPere: { type: String },
    telephone: { type: String },
    professionPere: { type: String },
    nomMere: { type: String },
    adresseMere: { type: String },
    telephoneMere: { type: String },
    ancienEtab: { type: String },
    ancienClasse: { type: String },
    santeVigoureux: { type: Boolean },
    santeDelicat: { type: Boolean },
    carnetVaccination: { type: Boolean },
    medecinSoignant: { type: String },
    adressMedecin: { type: String },
    telephoneMedecin: { type: String },
    nomTuteur: { type: String },
    telephoneTuteur: { type: String },
    actif: { type: Boolean, default: true },
    unePhoto: { type: String },
    dispense: { type: Boolean }
  });
  
  const Eleve = mongoose.model('Eleve', eleveSchema);
  module.exports = Eleve;
  