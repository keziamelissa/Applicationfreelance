const mongoose = require('mongoose');

// Schéma pour matière
const matiereSchema = new mongoose.Schema({
    nom: { type: String, required: true },
    coefficient: { type: Number, required: true }
  });
  
  const Matiere = mongoose.model('Matiere', matiereSchema);
  module.exports = Matiere;