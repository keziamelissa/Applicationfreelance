const express = require('express');
const mongoose = require('mongoose');
const app = express();


// Définir les routes

app.use(express.json());
app.use('/NoteClasse', require('./routes/notesClasse'));
app.use('/Matiere', require('./routes/matiere'));
app.use('/Composer', require('./routes/composer'));
app.use('/Eleve', require('./routes/eleve'));
app.use('/Classe', require('./routes/classe'));
app.use('/Appartenir', require('./routes/appartenir'));



module.exports = app;
