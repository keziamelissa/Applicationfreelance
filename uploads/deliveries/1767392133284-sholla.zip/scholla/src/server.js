const express = require("express");
const connectDB = require("../config/db"); // Assurez-vous que le chemin est correct
const dotenv = require("dotenv").config();
const authRoutes = require('./routes/authRoutes');
const matiereRoute = require('./routes/matiere');
const classeRoute = require('./routes/classe');
const composerRoute = require('./routes/composer');
const eleveRoute = require('./routes/eleve');
const appartenirRoute = require('./routes/appartenir');
const notesClasseRoute = require('./routes/notesClasse');



// Initialisation de l'application Express
const app = express();

// Connexion à la base de données
connectDB();

// Middleware pour analyser les requêtes JSON
app.use(express.json());

// Utiliser les routes d'authentification
app.use('/auth', authRoutes);



// Utilisation des routes
app.use('/api/matiere', matiereRoute);
app.use('/api/eleve', eleveRoute);
app.use('/api/notesClasse', notesClasseRoute);
app.use('/api/composer', composerRoute);
app.use('/api/appartenir', appartenirRoute);
app.use('/api/classe', classeRoute);



// Utilisation de la route pour "Appartenir"
app.use('/Appartenir', require('./routes/appartenir'));
app.use('/Composer', require('./routes/composer'));
app.use('/Eleve', require('./routes/eleve'));
app.use('/Matiere', require('./routes/matiere'));
app.use('/Classe', require('./routes/classe'));


const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`Le serveur a démarré sur le port ${port}`));
