// routes/matiereRoutes.js

const express = require('express');
const router = express.Router();
const appartenirController = require('../controllers/appartenirController');
const authMiddleware = require('../../middleware/authMiddlewaire');


// Créer une nouvelle matière
router.post('/',authMiddleware, appartenirController.createAppartenir);

// Lire toutes les matières
router.get('/', appartenirController.getAllAppartenirs);

// Mettre à jour une matière
router.put('/:id', appartenirController.updateAppartenir);

// Supprimer une matière
router.delete('/:id', appartenirController.deleteAppartenir);

module.exports = router;
