// routes/matiereRoutes.js

const express = require('express');
const router = express.Router();
const classeController = require('../controllers/classeCotroller');
const authMiddleware = require('../../middleware/authMiddlewaire');


// Créer une nouvelle matière
router.post('/', classeController.createClasse);

// Lire toutes les matières
router.get('/', classeController.getAllClasses);

// Mettre à jour une matière
router.put('/:id', classeController.updateClasse);

// Supprimer une matière
router.delete('/:id', classeController.deleteClasse);

module.exports = router;
