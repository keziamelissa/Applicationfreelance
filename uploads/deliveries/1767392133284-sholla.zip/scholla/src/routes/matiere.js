// routes/matiereRoutes.js

const express = require('express');
const router = express.Router();
const matiereController = require('../controllers/matiereController');
const authMiddleware = require('../../middleware/authMiddlewaire');


// Créer une nouvelle matière
router.post('/',authMiddleware, matiereController.createMatiere);

// Lire toutes les matières
router.get('/', matiereController.getAllMatieres);

// Mettre à jour une matière
router.put('/:id', matiereController.updateMatiere);

// Supprimer une matière
router.delete('/:id', matiereController.deleteMatiere);

module.exports = router;
