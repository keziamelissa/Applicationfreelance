// routes/matiereRoutes.js

const express = require('express');
const router = express.Router();
const notesClasseController = require('../controllers/noteClasseController');
const authMiddleware = require('../../middleware/authMiddlewaire');


// Créer une nouvelle matière
router.post('/', notesClasseController.createNotesClasse);

// Lire toutes les matières
router.get('/', notesClasseController.getAllNotesClasses);

// Mettre à jour une matière
router.put('/:id', notesClasseController.updateNotesClasse);

// Supprimer une matière
router.delete('/:id', notesClasseController.deleteNotesClasse );

module.exports = router;
