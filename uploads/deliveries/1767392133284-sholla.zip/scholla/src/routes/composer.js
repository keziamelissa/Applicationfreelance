// routes/matiereRoutes.js

const express = require('express');
const router = express.Router();
const composerController = require('../controllers/composerController');
const authMiddleware = require('../../middleware/authMiddlewaire');


// Créer une nouvelle matière
router.post('/',authMiddleware, composerController.createComposer);

// Lire toutes les matières
router.get('/', composerController.getAllComposers);

// Mettre à jour une matière
router.put('/:id', composerController.updateComposer);

// Supprimer une matière
router.delete('/:id', composerController.deleteComposer);

module.exports = router;
