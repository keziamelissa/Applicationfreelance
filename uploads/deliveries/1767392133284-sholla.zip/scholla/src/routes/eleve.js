// routes/matiereRoutes.js

const express = require('express');
const router = express.Router();
const eleveController = require('../controllers/eleveController');
const authMiddleware = require('../../middleware/authMiddlewaire');


// Créer une nouvelle matière
router.post('/', eleveController.createEleve);

// Lire toutes les matières
router.get('/', eleveController.getAllEleves);

// Mettre à jour une matière
router.put('/:id', eleveController.updateEleve);

// Supprimer une matière
router.delete('/:id', eleveController.deleteEleve);

module.exports = router;
