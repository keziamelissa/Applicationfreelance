const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

// Route de connexion pour obtenir un token
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  // Simuler une vérification des identifiants (normalement tu vérifies avec ta base de données)
  if (username === 'admin' && password === 'password') {
    const token = jwt.sign({ username }, 'your_secret_key', { expiresIn: '1h' });
    res.json({ token });
  } else {
    res.status(401).json({ error: 'Identifiants incorrects' });
  }
});

module.exports = router;
