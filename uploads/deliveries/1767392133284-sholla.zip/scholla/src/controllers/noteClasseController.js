// controllers/ClasseController.js

const NotesClasse = require('../model/NoteClasse'); // Assurez-vous que le chemin est correct

// Créer une nouvelle Classe
exports.createNotesClasse = async (req, res) => {
  try {
    const newNotesClasse = new NotesClasse(req.body);
    await newNotesClasse.save();
    res.status(201).json(newNotesClasse);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la création de la noteclase' });
  }
};

// Lire toutes les Classes
exports.getAllNotesClasses = async (req, res) => {
  try {
    const notesClasses = await NotesClasse.find();
    res.json(notesClasses);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la récupération des noteclasse' });
  }
};

// Mettre à jour une Classe
exports.updateNotesClasse = async (req, res) => {
  try {
    const updatedNotesClasse = await NotesClasse.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedNotesClasse);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la mise à jour de la noteclasse' });
  }
};

// Supprimer une Classe
exports.deleteNotesClasse = async (req, res) => {
  try {
    await NotesClasse.findByIdAndDelete(req.params.id);
    res.json({ message: 'NotesClasse supprimée avec succès' });
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la suppression de la notesClasse' });
  }
};
