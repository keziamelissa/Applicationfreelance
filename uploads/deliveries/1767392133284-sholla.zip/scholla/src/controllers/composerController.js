// controllers/composerController.js

const Composer = require('../model/Composer'); // Assurez-vous que le chemin est correct

// Créer une nouvelle composante
exports.createComposer = async (req, res) => {
  try {
    const newComposer = new Composer(req.body);
    await newComposer.save();
    res.status(201).json(newComposer);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la création de la composante' });
  }
};

// Lire toutes les comosantes
exports.getAllComposers = async (req, res) => {
  try {
    const composers = await Composer.find();
    res.json(composers);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la récupération des composante' });
  }
};

// Mettre à jour une matière
exports.updateComposer = async (req, res) => {
  try {
    const updatedComposer = await Composer.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedComposer);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la mise à jour de la composante' });
  }
};

// Supprimer une composante
exports.deleteComposer = async (req, res) => {
  try {
    await Composer.findByIdAndDelete(req.params.id);
    res.json({ message: 'composante supprimée avec succès' });
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la suppression de la composante' });
  }
};
