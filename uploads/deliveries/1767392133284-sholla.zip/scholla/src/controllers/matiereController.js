// controllers/matiereController.js

const Matiere = require('../model/Matiere'); // Assurez-vous que le chemin est correct

// Créer une nouvelle matière
exports.createMatiere = async (req, res) => {
  try {
    const newMatiere = new Matiere(req.body);
    await newMatiere.save();
    res.status(201).json(newMatiere);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la création de la matière' });
  }
};

// Lire toutes les matières
exports.getAllMatieres = async (req, res) => {
  try {
    const matieres = await Matiere.find();
    res.json(matieres);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la récupération des matières' });
  }
};

// Mettre à jour une matière
exports.updateMatiere = async (req, res) => {
  try {
    const updatedMatiere = await Matiere.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedMatiere);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la mise à jour de la matière' });
  }
};

// Supprimer une matière
exports.deleteMatiere = async (req, res) => {
  try {
    await Matiere.findByIdAndDelete(req.params.id);
    res.json({ message: 'Matière supprimée avec succès' });
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la suppression de la matière' });
  }
};
