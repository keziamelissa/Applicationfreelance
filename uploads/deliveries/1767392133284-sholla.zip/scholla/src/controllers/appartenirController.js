// controllers/appartenirController.js

const Appartenir = require('../model/Appartenir'); // Assurez-vous que le chemin est correct

// Créer une nouvelle appartenance
exports.createAppartenir = async (req, res) => {
  try {
    const newAppartenir = new Appartenir(req.body);
    await newAppartenir.save();
    res.status(201).json(newAppartenir);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la création de l appartenance' });
  }
};

// Lire toutes les appartenance
exports.getAllAppartenirs = async (req, res) => {
  try {
    const appartenirs = await Appartenir.find();
    res.json(appartenirs);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la récupération des appartenances' });
  }
};

// Mettre à jour une appartenance
exports.updateAppartenir = async (req, res) => {
  try {
    const updatedAppartenir = await Appartenir.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedAppartenir);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la mise à jour de l appartenance' });
  }
};

// Supprimer une appartenance
exports.deleteAppartenir = async (req, res) => {
  try {
    await Appartenir.findByIdAndDelete(req.params.id);
    res.json({ message: 'appartenance supprimée avec succès' });
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la suppression de l appartenance' });
  }
};
