// controllers/eleveController.js

const Eleve = require('../model/Eleve'); // Assurez-vous que le chemin est correct

// Créer une nouvelle ELeve
exports.createEleve = async (req, res) => {
  try {
    const newEleve = new Eleve(req.body);
    await newEleve.save();
    res.status(201).json(newMatiere);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la création de l eleve' });
  }
};

// Lire toutes les Eleves
exports.getAllEleves = async (req, res) => {
  try {
    const eleves = await Eleve.find();
    res.json(eleves);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la récupération des eleves' });
  }
};

// Mettre à jour un Eleve
exports.updateEleve = async (req, res) => {
  try {
    const updatedEleve = await Eleve.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedEleve);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la mise à jour de l eleve' });
  }
};

// Supprimer un eleve
exports.deleteEleve = async (req, res) => {
  try {
    await Eleve.findByIdAndDelete(req.params.id);
    res.json({ message: 'Eleve supprimée avec succès' });
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la suppression de l eleve' });
  }
};
