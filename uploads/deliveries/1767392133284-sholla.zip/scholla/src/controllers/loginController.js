const jwt = require('jsonwebtoken');

// Fonction d'authentification pour générer un token JWT
exports.login = (req, res) => {
  const user = { username: req.body.username }; // Récupérer le username du body

  // Créer le token
  const token = jwt.sign(user, 'your_secret_key', { expiresIn: '1h' });

  // Envoyer le token comme réponse
  res.json({ token });
};
