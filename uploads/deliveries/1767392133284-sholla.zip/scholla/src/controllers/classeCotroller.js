// controllers/classeController.js

const Classe = require('../model/Classe'); // Assurez-vous que le chemin est correct

// Créer une nouvelle classe
exports.createClasse = async (req, res) => {
  try {
    const newClasse = new Classe(req.body);
    await newClasse.save();
    res.status(201).json(newClasse);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la création de la classe' });
  }
};

// Lire toutes les classes
exports.getAllClasses = async (req, res) => {
  try {
    const classes = await Classe.find();
    res.json(classes);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la récupération des classes' });
  }
};

// Mettre à jour une classe
exports.updateClasse = async (req, res) => {
  try {
    const updatedClasse = await Classe.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedClasse);
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la mise à jour de la classe' });
  }
};

// Supprimer une classe
exports.deleteClasse = async (req, res) => {
  try {
    await Classe.findByIdAndDelete(req.params.id);
    res.json({ message: 'classe supprimée avec succès' });
  } catch (err) {
    res.status(500).json({ error: 'Erreur lors de la suppression de la classe' });
  }
};
