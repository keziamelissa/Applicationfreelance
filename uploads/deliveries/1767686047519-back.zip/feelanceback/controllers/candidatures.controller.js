import { Candidature } from '../models/index.js';
import { list, getOne, createOne, updateOne, deleteOne } from './crudFactory.js';

export const listCandidatures = list(Candidature);
export const getCandidature = getOne(Candidature);
export const createCandidature = createOne(Candidature);
export const updateCandidature = updateOne(Candidature);
export const deleteCandidature = deleteOne(Candidature);

// List all candidatures for a given task (tache)
export const listCandidaturesByTache = async (req, res, next) => {
  try {
    const { tacheId } = req.params;
    const rows = await Candidature
      .find({ idTache: tacheId })
      .populate('idFreelanceur', 'nom prenom profile_photo');
    res.json(rows);
  } catch (e) { next(e); }
};

// Apply to a task as the authenticated freelancer
export const applyToTache = async (req, res, next) => {
  try {
    const { tacheId } = req.params;
    const userId = req.user?.id || req.user?._id;
    const { lettreDeMotivation, budgetProposer } = req.body || {};

    if (!userId) return res.status(401).json({ error: 'Non authentifié' });

    // Prevent duplicate active applications
    const existing = await Candidature.findOne({
      idTache: tacheId,
      idFreelanceur: userId,
      status: { $ne: 'retirer' },
    });
    if (existing) return res.status(409).json({ error: 'Candidature déjà envoyée pour cette tâche' });

    const created = await Candidature.create({
      idTache: tacheId,
      idFreelanceur: userId,
      lettreDeMotivation,
      budgetProposer,
    });
    res.status(201).json(created);
  } catch (e) { next(e); }
};
