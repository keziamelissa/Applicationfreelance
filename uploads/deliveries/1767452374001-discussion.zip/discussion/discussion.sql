-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 27 oct. 2024 à 21:57
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `discussion`
--

-- --------------------------------------------------------

--
-- Structure de la table `chat`
--

CREATE TABLE `chat` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `chat`
--

INSERT INTO `chat` (`id`, `type`, `name`) VALUES
(1, 'private', 'Chat with Alice'),
(2, 'private', 'Chat with Bob'),
(3, 'group', 'Study Group 1'),
(4, 'group', 'Project Discussion'),
(5, 'private', 'Chat with Charlie'),
(6, 'group', 'Friends Chat'),
(7, 'private', 'Chat with David'),
(8, 'group', 'Work Chat'),
(9, 'group', 'Family Chat'),
(10, 'private', 'Chat with Eve');

-- --------------------------------------------------------

--
-- Structure de la table `chatusers`
--

CREATE TABLE `chatusers` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `chat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `chatusers`
--

INSERT INTO `chatusers` (`id`, `user`, `chat`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 2),
(4, 4, 3),
(5, 5, 3),
(6, 1, 3),
(7, 2, 4),
(8, 3, 4),
(9, 4, 4),
(10, 5, 4),
(11, 6, 4),
(12, 7, 4);

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `content` text NOT NULL,
  `sender` int(11) NOT NULL,
  `chat` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `message`
--

INSERT INTO `message` (`id`, `content`, `sender`, `chat`, `created_at`) VALUES
(1, 'Bonjour, comment ça va ?', 1, 1, '2024-10-27 20:05:04'),
(2, 'Je vais bien, merci !', 2, 1, '2024-10-27 20:05:04'),
(3, 'Commençons le projet !', 3, 2, '2024-10-27 20:05:04'),
(4, 'Bienvenue dans le groupe LPSIC !', 4, 3, '2024-10-27 20:05:04'),
(5, 'Hâte de travailler ensemble !', 5, 3, '2024-10-27 20:05:04'),
(6, 'Bonjour à tous dans Chimie !', 2, 4, '2024-10-27 20:05:04'),
(7, 'J\'ai une idée pour le projet de Chimie.', 3, 4, '2024-10-27 20:05:04'),
(8, 'Nous devrions nous rencontrer.', 4, 4, '2024-10-27 20:05:04'),
(9, 'Cela semble bien.', 5, 4, '2024-10-27 20:05:04'),
(10, 'Je suis d\'accord.', 6, 4, '2024-10-27 20:05:04'),
(11, 'Prêts à commencer.', 7, 4, '2024-10-27 20:05:04');

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `chat_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'Alice Duponten', 'alice.dupont@example.com', '$2y$10$cD/SNHGigEQuH.tsTOfxHucQ3MQAQNvpURiTjFVUjqX6KPcc9OZn.', '2024-10-26 16:15:34'),
(2, 'Bob Martin', 'bob.martin@example.com', '$2y$10$cD/SNHGigEQuH.tsTOfxHucQ3MQAQNvpURiTjFVUjqX6KPcc9OZn.', '2024-10-26 16:15:34'),
(3, 'Charles Bernard', 'charles.bernard@example.com', '$2y$10$cD/SNHGigEQuH.tsTOfxHucQ3MQAQNvpURiTjFVUjqX6KPcc9OZn.', '2024-10-26 16:15:34'),
(4, 'Danielle Noel', 'danielle.noel@example.com', '$2y$10$cD/SNHGigEQuH.tsTOfxHucQ3MQAQNvpURiTjFVUjqX6KPcc9OZn.', '2024-10-26 16:15:34'),
(5, 'Eva Simon', 'eva.simon@example.com', '$2y$10$cD/SNHGigEQuH.tsTOfxHucQ3MQAQNvpURiTjFVUjqX6KPcc9OZn.', '2024-10-26 16:15:34'),
(6, 'Fabien Lefevre', 'fabien.lefevre@example.com', '$2y$10$cD/SNHGigEQuH.tsTOfxHucQ3MQAQNvpURiTjFVUjqX6KPcc9OZn.', '2024-10-26 16:15:34'),
(7, 'Gilles Durant', 'gilles.durant@example.com', '$2y$10$cD/SNHGigEQuH.tsTOfxHucQ3MQAQNvpURiTjFVUjqX6KPcc9OZn.', '2024-10-26 16:15:34'),
(8, 'Helene Petit', 'helene.petit@example.com', '$2y$10$cD/SNHGigEQuH.tsTOfxHucQ3MQAQNvpURiTjFVUjqX6KPcc9OZn.', '2024-10-26 16:15:34'),
(11, 'Henoc N&#039;GASAMA', 'ngasamah@gmail.com', '$2y$10$cD/SNHGigEQuH.tsTOfxHucQ3MQAQNvpURiTjFVUjqX6KPcc9OZn.', '2024-10-26 17:30:01'),
(15, 'Alice', 'alice@example.com', 'password123', '2024-10-27 19:57:30'),
(16, 'Bob', 'bob@example.com', 'password123', '2024-10-27 19:57:30'),
(17, 'Charlie', 'charlie@example.com', 'password123', '2024-10-27 19:57:30'),
(18, 'David', 'david@example.com', 'password123', '2024-10-27 19:57:30'),
(19, 'Eve', 'eve@example.com', 'password123', '2024-10-27 19:57:30'),
(20, 'Frank', 'frank@example.com', 'password123', '2024-10-27 19:57:30'),
(21, 'Grace', 'grace@example.com', 'password123', '2024-10-27 19:57:30'),
(22, 'Hannah', 'hannah@example.com', 'password123', '2024-10-27 19:57:30'),
(23, 'Isaac', 'isaac@example.com', 'password123', '2024-10-27 19:57:30'),
(24, 'Jack', 'jack@example.com', 'password123', '2024-10-27 19:57:30');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `chatusers`
--
ALTER TABLE `chatusers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user` (`user`),
  ADD KEY `chat` (`chat`);

--
-- Index pour la table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender` (`sender`),
  ADD KEY `chat` (`chat`);

--
-- Index pour la table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `chatusers`
--
ALTER TABLE `chatusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `chatusers`
--
ALTER TABLE `chatusers`
  ADD CONSTRAINT `chatusers_ibfk_1` FOREIGN KEY (`user`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chatusers_ibfk_2` FOREIGN KEY (`chat`) REFERENCES `chat` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `message_ibfk_1` FOREIGN KEY (`sender`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `message_ibfk_2` FOREIGN KEY (`chat`) REFERENCES `chat` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`chat_id`) REFERENCES `chats` (`id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
