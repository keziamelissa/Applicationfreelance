<?php
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../controllers/UserController.php';
require_once __DIR__ . '/../controllers/ChatController.php';
require_once __DIR__ . '/../controllers/MessageController.php';

$database = new Database();
$db = $database->getConnection();

$requestMethod = $_SERVER["REQUEST_METHOD"];
$uri = explode('/', parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

if ($uri[2] === 'users') {
    $userController = new UserController($db);
    switch ($requestMethod) {
        case 'GET':
            $id = isset($uri[3]) ? (int) $uri[3] : null;
            if ($id) {
                $userController->getUser($id);
            } else {
                $userController->getUsers();
            }
            break;

        case 'POST':
            $data = json_decode(file_get_contents("php://input"), true);
            $userController->createUser($data);
            break;

        case 'PUT':
            $id = isset($uri[3]) ? (int) $uri[3] : null;
            $data = json_decode(file_get_contents("php://input"), true);
            $userController->updateUser($id, $data);
            break;

        case 'PATCH':
            $id = isset($uri[3]) ? (int) $uri[3] : null;
            $data = json_decode(file_get_contents("php://input"), true);
            $userController->partialUpdateUser($id, $data);
            break;

        case 'DELETE':
            $id = isset($uri[3]) ? (int) $uri[3] : null;
            $userController->deleteUser($id);
            break;

        default:
            ResponseHelper::sendResponse(["message" => "Méthode non réconnue"], 405);
            break;
    }
} else if ($uri[2] === 'messages') {
    $messageController = new MessageController($db);
    switch ($requestMethod) {
        case 'GET':
            $id = isset($uri[3]) ? (int) $uri[3] : null;
            if ($id) {
                $messageController->getMessage($id);
            } else {
                $messageController->getMessages();
            }
            break;

        case 'POST':
            $data = json_decode(file_get_contents("php://input"), true);
            $messageController->createMessage($data);
            break;

        case 'PUT':
            $id = isset($uri[3]) ? (int) $uri[3] : null;
            $data = json_decode(file_get_contents("php://input"), true);
            $messageController->updateMessage($id, $data);
            break;

        case 'DELETE':
            $id = isset($uri[3]) ? (int) $uri[3] : null;
            $messageController->deleteMessage($id);
            break;

        default:
            ResponseHelper::sendResponse(["message" => "Méthode non réconnue"], 405);
            break;
    }
} else if ($uri[2] === 'chats') {
    $chatController = new ChatController($db);
    switch ($requestMethod) {
        case 'GET':
            $id = isset($uri[3]) ? (int) $uri[3] : null;
            if ($id) {
                $chatController->getChat($id);
            } else {
                $chatController->getChats();
            }
            break;

        case 'POST':
            $data = json_decode(file_get_contents("php://input"), true);
            $chatController->createChat($data);
            break;

        case 'PUT':
            $id = isset($uri[3]) ? (int) $uri[3] : null;
            $data = json_decode(file_get_contents("php://input"), true);
            $chatController->updateChat($id, $data);
            break;

        case 'DELETE':
            $id = isset($uri[3]) ? (int) $uri[3] : null;
            $chatController->deleteChat($id);
            break;

        default:
            ResponseHelper::sendResponse(["message" => "Méthode non réconnue"], 405);
            break;
    }
} else {
    ResponseHelper::sendResponse(["message" => "No endpoint at this URL"], 404);
}




