<?php
class Message {
    private $conn;
    private $table = "message";
    public $chat = "chat";

    public $id;
    public $content;
    public $sender;

    public function __construct($db) {
        $this->conn = $db;
    }




    ##############################################################
    #                       CRUD MESSAGES                        #
    ##############################################################

    public function readOne($id) {
        $query = "SELECT id, content, sender, chat FROM {$this->table} WHERE id = " . $id;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function read() {
        $query = "SELECT id, content, sender, chat FROM {$this->table}";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function create() {
        $query = "INSERT INTO {$this->table} SET content = :content, sender = :sender, chat = :chat";
        $stmt = $this->conn->prepare($query);

        $this->content = htmlspecialchars(strip_tags($this->content));
        $this->sender = htmlspecialchars(strip_tags($this->sender));
        $this->chat = htmlspecialchars(strip_tags($this->chat));

        $stmt->bindParam(":content", $this->content);
        $stmt->bindParam(":sender", $this->sender);
        $stmt->bindParam(":chat", $this->chat);

        return $stmt->execute();
    }

    public function update() {
        $query = "UPDATE {$this->table} SET content = :content, chat = :chat WHERE id = :id";
        $stmt = $this->conn->prepare($query);

        $this->content = htmlspecialchars(strip_tags($this->content));
        $this->chat = htmlspecialchars(strip_tags($this->chat));
        $this->id = htmlspecialchars(strip_tags($this->id));

        $stmt->bindParam(":content", $this->content);
        $stmt->bindParam(":chat", $this->chat);
        $stmt->bindParam(":id", $this->id, PDO::PARAM_INT);

        return $stmt->execute();
    }

    public function delete() {
        $query = "DELETE FROM {$this->table} WHERE id = :id";
        $stmt = $this->conn->prepare($query);

        $this->id = htmlspecialchars(strip_tags($this->id));
        $stmt->bindParam(":id", $this->id, PDO::PARAM_INT);

        return $stmt->execute();
    }





    ##############################################################
    #              RECUPERER LES MESSAGES D'UN CHAT              #
    ##############################################################

    public function getMessagesByChat($chatId) {
        $query = "SELECT id, content, sender, chat FROM {$this->table} WHERE chat = :chat";
        $stmt = $this->conn->prepare($query);

        $chatId = htmlspecialchars(strip_tags($chatId));
        $stmt->bindParam(":chat", $chatId, PDO::PARAM_INT);

        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
