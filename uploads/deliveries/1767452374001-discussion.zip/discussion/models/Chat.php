<?php
class Chat
{
    private $conn;
    private $table = "chat";
    private $chat_users = "chatusers";
    private $users = "users";

    public $id;
    public $name;
    public $type;

    public function __construct($db)
    {
        $this->conn = $db;
    }





    ##############################################################
    #                       CRUD CHAT                            #
    ##############################################################

    public function readOne($id)
    {
        $query = "SELECT id, type, name FROM {$this->table} WHERE id = " . $id;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function read()
    {
        $query = "SELECT id, type, name FROM {$this->table}";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function create()
    {
        $query = "INSERT INTO {$this->table} SET type = :type, name = :name";
        $stmt = $this->conn->prepare($query);

        $this->type = htmlspecialchars(strip_tags($this->type));
        $this->name = htmlspecialchars(strip_tags($this->name));

        $stmt->bindParam(":type", $this->type);
        $stmt->bindParam(":name", $this->name);

        return $stmt->execute();
    }

    public function update()
    {
        $query = "UPDATE {$this->table} SET type = :type, name = :name WHERE id = :id";
        $stmt = $this->conn->prepare($query);

        $this->type = htmlspecialchars(strip_tags($this->type));
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->id = htmlspecialchars(strip_tags($this->id));

        $stmt->bindParam(":type", $this->type);
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":id", $this->id, PDO::PARAM_INT);

        return $stmt->execute();
    }

    public function delete()
    {
        $query = "DELETE FROM {$this->table} WHERE id = :id";
        $stmt = $this->conn->prepare($query);

        $this->id = htmlspecialchars(strip_tags($this->id));
        $stmt->bindParam(":id", $this->id, PDO::PARAM_INT);

        return $stmt->execute();
    }





    ##############################################################
    #              GESTION DES PARTICIPANTS D'UN CHAT            #
    ##############################################################

    public function getChatUsers($id)
    {
        $query = "SELECT user.id, user.email, user.name, chat.id as chat
                  FROM {$this->chat_users} as chat_user
                  INNER JOIN {$this->users} as user ON chat_user.user = user.id 
                  INNER JOIN {$this->table} as chat ON chat_user.chat = chat.id 
                  WHERE chat.id = :id";

        $stmt = $this->conn->prepare($query);

        $id = htmlspecialchars(strip_tags($id));
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addUserToChat($userId)
    {
        $query = "INSERT INTO {$this->chat_users} (user, chat) VALUES (:user, :chat)";
        $stmt = $this->conn->prepare($query);

        $chatId = htmlspecialchars(strip_tags($this->id));
        $stmt->bindParam(':user', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':chat', $chatId, PDO::PARAM_INT);

        return $stmt->execute();
    }

    public function removeUserFromChat($userId)
    {
        $query = "DELETE FROM {$this->chat_users} WHERE user = :user AND chat = :chat";
        $stmt = $this->conn->prepare($query);

        $chatId = htmlspecialchars(strip_tags($this->id));
        $stmt->bindParam(':user', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':chat', $chatId, PDO::PARAM_INT);

        return $stmt->execute();
    }
}
