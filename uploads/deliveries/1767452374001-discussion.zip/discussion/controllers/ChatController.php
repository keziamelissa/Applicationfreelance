<?php
require_once __DIR__ . '/../models/Chat.php';
require_once __DIR__ . '/../helpers/ResponseHelper.php';

class ChatController
{
    private $chat;

    public function __construct($db)
    {
        $this->chat = new Chat($db);
    }

    public function getChat($id)
    {
        if ($id) {
            $chat = $this->chat->readOne($id);

            if ($chat) {
                ResponseHelper::sendResponse($chat);
            } else {
                ResponseHelper::sendResponse(["message" => "No chat with this id"], 404);
            }
        } else {
            $stmt = $this->chat->read();
            $chats = $stmt->fetchAll(PDO::FETCH_ASSOC);

            ResponseHelper::sendResponse($chats);
        }
    }

    public function getChats()
    {
        $stmt = $this->chat->read();
        $chats = $stmt->fetchAll(PDO::FETCH_ASSOC);
        ResponseHelper::sendResponse($chats);
    }

    public function createChat($data)
    {
        $this->chat->name = $data['name'];
        $this->chat->type = $data['type'];

        if ($this->chat->create()) {
            ResponseHelper::sendResponse($data, 201);
        } else {
            ResponseHelper::sendResponse(["message" => "Failed to create chat"], 500);
        }
    }

    public function updateChat($id, $data)
    {
        if ($this->chat->readOne($id)->rowCount() > 0) {
            $this->chat->id = $id;
            $this->chat->name = $data['name'];
            $this->chat->type = $data['type'];

            if ($this->chat->update()) {
                ResponseHelper::sendResponse($data);
            } else {
                ResponseHelper::sendResponse(["message" => "Failed to update chat"], 500);
            }
        } else {
            ResponseHelper::sendResponse(["message" => "No chat with this id"], 404);
        }
    }

    public function deleteChat($id)
    {
        if ($this->chat->readOne($id)->rowCount() > 0) {
            $this->chat->id = $id;
            if ($this->chat->delete()) {
                ResponseHelper::sendResponse(["message" => "Chat $id deleted successfully"]);
            } else {
                ResponseHelper::sendResponse(["message" => "Failed to delete chat"], 500);
            }
        } else {
            ResponseHelper::sendResponse(["message" => "No chat with this id"], 404);
        }
    }
}
