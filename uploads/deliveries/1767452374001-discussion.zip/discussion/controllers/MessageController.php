<?php
require_once __DIR__ . '/../models/Message.php';
require_once __DIR__ . '/../helpers/ResponseHelper.php';

class MessageController
{
    private $message;

    public function __construct($db)
    {
        $this->message = new Message($db);
    }

    public function getMessage($id = null)
    {
        if ($id) {
            $message = $this->message->readOne($id);

            if ($message) {
                ResponseHelper::sendResponse($message);
            } else {
                ResponseHelper::sendResponse(["message" => "No user with this id"], 404);
            }
        } else {
            $stmt = $this->message->read();
            $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

            ResponseHelper::sendResponse($messages);
        }
    }

    public function getMessages()
    {
        $stmt = $this->message->read();
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        ResponseHelper::sendResponse($messages);
    }

    public function createMessage($data)
    {
        $this->message->content = $data['content'];
        $this->message->sender = $data['sender'];
        $this->message->chat = $data['chat'];

        if ($this->message->create()) {
            ResponseHelper::sendResponse($data, 201);
        } else {
            ResponseHelper::sendResponse(["message" => "Failed to create message"], 500);
        }
    }

    public function updateMessage($id, $data)
    {
        if ($this->message->readOne($id)->rowCount() > 0) {
            $this->message->id = $id;
            $this->message->content = $data['content'];
            $this->message->chat = $data['chat'];

            if ($this->message->update()) {
                ResponseHelper::sendResponse($data);
            } else {
                ResponseHelper::sendResponse(["message" => "Failed to update message"], 500);
            }
        } else {
            ResponseHelper::sendResponse(["message" => "No message with this id"], 404);
        }
    }

    public function deleteMessage($id)
    {
        if ($this->message->readOne($id)->rowCount() > 0) {
            $this->message->id = $id;
            if ($this->message->delete()) {
                ResponseHelper::sendResponse(["message" => "Message $id deleted successfully"]);
            } else {
                ResponseHelper::sendResponse(["message" => "Failed to delete message"], 500);
            }
        } else {
            ResponseHelper::sendResponse(["message" => "No message with this id"], 404);
        }
    }
}
