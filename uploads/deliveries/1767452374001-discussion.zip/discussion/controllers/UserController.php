<?php
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../helpers/ResponseHelper.php';

class UserController
{
    private $user;

    public function __construct($db)
    {
        $this->user = new User($db);
    }

    public function getUser($id = null)
    {
        if ($id) {
            $user = $this->user->readOne($id);

            if ($user) {
                ResponseHelper::sendResponse($user);
            } else {
                ResponseHelper::sendResponse(["message" => "No user with this id"], 404);
            }
        } else {
            $stmt = $this->user->read();
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

            ResponseHelper::sendResponse($users);
        }
    }


    public function getUsers()
    {
        $stmt = $this->user->read();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        ResponseHelper::sendResponse($users);
    }

    public function createUser($data)
    {
        $this->user->name = $data['name'];
        $this->user->email = $data['email'];
        $this->user->password = $data['password'];

        if ($this->user->create()) {
            ResponseHelper::sendResponse($data, 201);
        } else {
            ResponseHelper::sendResponse(["message" => "Failed to create user"], 500);
        }
    }

    public function updateUser($id, $data)
    {
        if ($this->user->readOne($id)->rowCount() > 0) {

            $this->user->id = $id;
            $this->user->name = $data['name'];
            $this->user->email = $data['email'];

            if ($this->user->update()) {
                ResponseHelper::sendResponse($data);
            } else {
                ResponseHelper::sendResponse(["message" => "Failed to update user"], 500);
            }
        } else {
            ResponseHelper::sendResponse(["message" => "No user with this id"], 404);
        }
    }

    public function partialUpdateUser($id, $data)
    {
        if ($this->user->readOne($id)->rowCount() > 0) {

            $this->user->id = $id;

            if (isset($data['name'])) {
                $this->user->name = $data['name'];
            }
            if (isset($data['email'])) {
                $this->user->email = $data['email'];
            }

            if ($this->user->partialUpdate()) {
                ResponseHelper::sendResponse($data);
            } else {
                ResponseHelper::sendResponse(["message" => "Failed to update user"], 500);
            }
        } else {
            ResponseHelper::sendResponse(["message" => "No user with this id"], 404);
        }
    }


    public function deleteUser($id)
    {
        if ($this->user->readOne($id)->rowCount() > 0) {
            $this->user->id = $id;
            if ($this->user->delete()) {
                ResponseHelper::sendResponse(["message" => "User $id deleted successfully"]);
            } else {
                ResponseHelper::sendResponse(["message" => "Failed to delete user"], 500);
            }
        } else {
            ResponseHelper::sendResponse(["message" => "No user with this id"], 404);
        }

    }
}
